package net.mcreator.pentamorph.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

public class QuintessonLarvaOnEntityTickUpdateProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof Player _plr ? _plr.getAbilities().getWalkingSpeed() : 0) > 0.25) {
			entity.setSprinting((true));
		} else {
			entity.setSprinting((false));
		}
	}
}
