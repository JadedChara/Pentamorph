
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.pentamorph.init;

import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.GameRules;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class PentamorphModGameRules {
	public static final GameRules.Key<GameRules.BooleanValue> DOQUINTSPAWNING = GameRules.register("doQuintSpawning", GameRules.Category.MOBS,
			GameRules.BooleanValue.create(true));
}
