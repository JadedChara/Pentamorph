package net.mcreator.pentamorph.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.pentamorph.init.PentamorphModGameRules;

public class QuintessonLarvaNaturalEntitySpawningConditionProcedure {
	public static boolean execute(LevelAccessor world) {
		if (world.getLevelData().getGameRules().getBoolean(PentamorphModGameRules.DOQUINTSPAWNING) == true) {
			return true;
		}
		return false;
	}
}
