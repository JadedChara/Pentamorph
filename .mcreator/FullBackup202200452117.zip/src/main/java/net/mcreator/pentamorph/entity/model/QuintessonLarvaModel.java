package net.mcreator.pentamorph.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.pentamorph.entity.QuintessonLarvaEntity;

public class QuintessonLarvaModel extends AnimatedGeoModel<QuintessonLarvaEntity> {
	@Override
	public ResourceLocation getAnimationResource(QuintessonLarvaEntity entity) {
		return new ResourceLocation("pentamorph", "animations/quintlarva.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(QuintessonLarvaEntity entity) {
		return new ResourceLocation("pentamorph", "geo/quintlarva.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(QuintessonLarvaEntity entity) {
		return new ResourceLocation("pentamorph", "textures/entities/quintslug.png");
	}

}
